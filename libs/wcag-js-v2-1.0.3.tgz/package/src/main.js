import { getHtmlReportByCategory } from './reportByCategory.js';
import {getHtmlReportByGuideLine} from './reportByGuideline.js';
import {getJsonReport} from './jsonReport.js';
import { init, analyse } from './wcagExe.js';
import { getHtmlPerformanceMetrics } from './performanceReport.js';
 
export{ init, getHtmlReportByCategory, getHtmlReportByGuideLine,getJsonReport, analyse, getHtmlPerformanceMetrics}