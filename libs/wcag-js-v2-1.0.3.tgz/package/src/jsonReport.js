import { deserializedAxeResults, deserializedStatistics, deserializedLighthouseResults } from "./utils.js";

export const getJsonReport = async () => {
    try {

        let statsData = deserializedStatistics();
        let lightHouseViolations = await deserializedLighthouseResults();
        let axeViolations = await deserializedAxeResults();
        let allViolations = lightHouseViolations.concat(axeViolations);

        let updatedSummary = includeAxeStatistics(statsData, axeViolations);
        let overView = createOverViewJson(updatedSummary);
        let jsonData = createJsonWithSummaryAndDetails(overView, updatedSummary, allViolations);

        return JSON.stringify(jsonData);

    } catch (error) {
        console.error('Error creating JSON:', error);
        throw error;
    }
};

export const createJsonWithSummaryAndDetails = (overViewData, statistics, violations) => {
    return {
        overview: overViewData,
        summary: statistics,
        details: violations,
    };
};


export const includeAxeStatistics = (axeStatsData, axeViolations) => {

    const updatedStatistics = [];

    axeStatsData.forEach((item) => {
        let report = axeViolations.filter(c => c.url === item.url);

        let seriousItems = (report.filter(c => c.type === "serious")).length || 0;
        let criticalItems = (report.filter(c => c.type === "critical")).length || 0;
        let moderateCount = (report.filter(c => c.type === "moderate")).length || 0;

        updatedStatistics.push({
            critical: criticalItems,
            serious:seriousItems,
            medium: moderateCount,
            url: item.url
        });
    })

    return updatedStatistics;
}

export const createOverViewJson = (statistics) => {

    let totalCritical = 0;
    let totalSerious=0;
    let totalMedium = 0; 
    let totalPages=0;
    let overViewList = [];

    statistics.forEach((item) => {
        let criticalCount = parseInt(item.critical);
        let seriousCount = parseInt(item.serious);
        let mediumCount = parseInt(item.medium);

        totalCritical += criticalCount;
        totalSerious += seriousCount;
        totalMedium += mediumCount;
        totalPages+=1;
    })

    overViewList.push({
        totalPages:totalPages,
        critical: totalCritical,
        serious: totalSerious,
        medium: totalMedium
    });

    return overViewList;
}