/* global axe */
import { getDateString } from "./utils.js";
import { wcagResult } from "./global.js";
import axeCore from 'axe-core';
import lighthouse from 'lighthouse'

const options = {
   logLevel: 'info',
   output: 'json',
   onlyCategories: ['accessibility', 'performance', 'seo']
};

export const init = async () => {
   wcagResult.startDateTime = getDateString("dd-MM-yyyy HH:mm:ss")
}

export const analyse = async (driver, pageKey) => {

   let visitedUrl = await driver.getUrl()
   let updatedUrl = visitedUrl

   if (pageKey) {
      let pageUniqueKey = pageKey.trim();
      let suffix = pageUniqueKey.length > 0
         ? '[' + pageUniqueKey + ']'
         : '';

      updatedUrl = `${visitedUrl}${suffix}`;
   }

   if (!wcagResult.visitedPageUrls.has(updatedUrl)) {

      wcagResult.visitedPageUrls.set(updatedUrl, await driver.getTitle())

      await driver.setTimeout({ "script": 120000 });

      await new Promise(resolve => setTimeout(resolve, 1000))

      await collectLightHouseMetrics(visitedUrl, updatedUrl);

      await collectAxeAccessibilityIssues(driver, updatedUrl);

   }
}

export const collectLightHouseMetrics = async (url, updatedUrl) => {

   const result = await lighthouse(url, options);

   const failingA11yAudits = Object.values(result.lhr.audits)
      .filter(a => a.score !== 1 && a.scoreDisplayMode !== 'notApplicable');

   let jsonReportObj = {};
   jsonReportObj[updatedUrl] = failingA11yAudits;
   wcagResult.lighthouseViolations.push(jsonReportObj);

   let statsData = result?.artifacts?.Accessibility;
   let totalElements = statsData?.incomplete.length +
      statsData?.notApplicable.length +
      statsData?.passes.length +
      statsData?.violations.length

   let jsonStatisticsObj = {
      allItemCount: totalElements.toString(),
      totalElements: totalElements.toString(),
      pageTitle: updatedUrl,
      error: 0,
      contrast: 0,
      alert: 0,
      url: updatedUrl,
   };

   jsonStatisticsObj[updatedUrl] = jsonStatisticsObj;
   wcagResult.lighthouseStatistics.push(jsonStatisticsObj);

   let lhr = result.lhr;
   let audits = lhr.audits;
   let categories = lhr.categories;

   wcagResult.lighthousePerformanceMetrics.push({
      url: updatedUrl,
      generatedTime: lhr.fetchTime,
      formFactor: lhr.configSettings.formFactor,
      throttling: lhr.configSettings.throttlingMethod,
      performance: {
         score: categories.performance?.score ?? null,
         fcp: audits['first-contentful-paint'],
         lcp: audits['largest-contentful-paint'],
         tbt: audits['total-blocking-time'],
         cls: audits['cumulative-layout-shift'],
         speedIndex: audits['speed-index'],
         tti: audits['interactive'],
         ttfb: audits['server-response-time'] || audits['time-to-first-byte'],  // Time to First Byte
         domSize: audits['dom-size'],                   // DOM size / complexity
         totalBytes: audits['total-byte-weight'],       // total transfer size
         jsExecution: audits['bootup-time']             // JS execution / main thread time
      },
      accessibility: {
         score: categories.accessibility?.score ?? null
      },
      seo: {
         score: categories.seo?.score ?? null
      },
      diagnostics: pickDiagnostics(lhr)
   });
}

export const collectAxeAccessibilityIssues = async (driver, url) => {

   const { source } = axeCore;
   await driver.execute(source);

   let axeOptions = {};

   let response = await driver.executeAsync((options, done) => {
      axe.run(options, (err, results) => {
         if (err)
            done(err);
         done(JSON.parse(JSON.stringify(results)))
      });
   }, axeOptions);

   let incompleteData = response?.incomplete;
   let violationsData = response?.violations;
   let allViolations = incompleteData.concat(violationsData);

   let jsonReportObj = {};
   jsonReportObj[url] = allViolations;
   wcagResult.axeViolations.push(jsonReportObj);

   let totalElements = allViolations?.length +
      response?.inapplicable?.length +
      response?.passes.length

   let jsonStatisticsObj = {
      allItemCount: totalElements.toString(),
      totalElements: totalElements.toString(),
      pageTitle: url,
      error: 0,
      contrast: 0,
      alert: 0,
      url: url,
   };

   jsonStatisticsObj[url] = jsonStatisticsObj;
   wcagResult.axeStatistics.push(jsonStatisticsObj);
}

function pickDiagnostics(lhr) {
   const ids = [
      'modern-image-formats',
      'render-blocking-resources',
      'unused-javascript',    // Reduce unused JavaScript
      'unused-css-rules',     // Remove unused CSS
      'uses-responsive-images',
      'uses-optimized-images',
      'mainthread-work-breakdown',
      'total-byte-weight'
   ];

   return ids
      .map(id => lhr.audits[id])
      .filter(a => a && a.score !== 1); // only non-perfect audits
}