import { wcagResult } from "./global.js";

function scoreInfo(score0to1) {
    if (score0to1 == null) return { scoreText: '–', cls: 'score-bad' };
    const score = Math.round(score0to1 * 100);
    if (score >= 90) return { scoreText: String(score), cls: 'score-good' };
    if (score >= 50) return { scoreText: String(score), cls: 'score-ok' };
    return { scoreText: String(score), cls: 'score-bad' };
}

function buildCard(page) {
    const perfScore = scoreInfo(page.performance.score);
    const seoScore = scoreInfo(page.seo.score);
    const accScore = scoreInfo(page.accessibility.score);

    const metric = page.performance;

    const diagnostics = page.diagnostics || [];
    const issuesCount = diagnostics.length;

    const diagItemsHtml = diagnostics.map(audit => {
        let badgeClass = 'bg-success';
        let label = 'Pass';
        if (audit.score === null || audit.score === 0) {
            badgeClass = 'bg-danger';
            label = 'Fail';
        } else if (audit.score < 1) {
            badgeClass = 'bg-warning text-dark';
            label = 'Warn';
        }
        return `
      <li class="mb-1">
        <span class="badge ${badgeClass} badge-pill me-1">${label}</span>
        ${audit.title || audit.id}
      </li>`;
    }).join('\n');

    return `
    <div class="card mt-4 bg-light shadow-lg card mb-3">
      <div class="card-header bg-white border-0 pb-0">
        <div class="d-flex justify-content-between align-items-start">
          <div class="me-2">
            <div class="text-muted text-uppercase small">Page</div>
            <div class="url-text">${page.url}</div>
          </div>
          <div class="text-end">
            <div class="text-muted small">Scores</div>
            <div>
              <span class="score-badge ${perfScore.cls} me-1">Perf ${perfScore.scoreText}</span>
              <span class="score-badge ${seoScore.cls}">SEO ${seoScore.scoreText}</span>
              <span class="score-badge ${accScore.cls} me-1">A11y ${accScore.scoreText}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="card-body pt-2 pb-1">
        <div class="row g-2 mb-2">
          <div class="col-md-4">
            <div class="metric-label">FCP</div>
            <div class="metric-value">${metric.fcp?.displayValue || '–'}</div>
            <div class="metric-sub">first-contentful-paint</div>
          </div>
          <div class="col-md-4">
            <div class="metric-label">LCP</div>
            <div class="metric-value">${metric.lcp?.displayValue || '–'}</div>
            <div class="metric-sub">largest-contentful-paint</div>
          </div>
          <div class="col-md-4">
            <div class="metric-label">Speed Index</div>
            <div class="metric-value">${metric.speedIndex?.displayValue || '–'}</div>
            <div class="metric-sub">speed-index</div>
          </div>
          <div class="col-md-4">
            <div class="metric-label">TBT</div>
            <div class="metric-value">${metric.tbt?.displayValue || '–'}</div>
            <div class="metric-sub">total-blocking-time</div>
          </div>
          <div class="col-md-4">
            <div class="metric-label">CLS</div>
            <div class="metric-value">${metric.cls?.displayValue || '–'}</div>
            <div class="metric-sub">cumulative-layout-shift</div>
          </div>
          <div class="col-md-4">
            <div class="metric-label">TTI</div>
            <div class="metric-value">${metric.tti?.displayValue || '–'}</div>
            <div class="metric-sub">interactive</div>
          </div>
        </div>
        <div class="row g-2 mb-2">
          <div class="col-md-4">
            <div class="metric-label">TTFB</div>
            <div class="metric-value">${metric.ttfb?.displayValue || '–'}</div>
            <div class="metric-sub">${metric.ttfb?.title || 'server-response-time'}</div>
          </div>
          <div class="col-md-4">
            <div class="metric-label">DOM Size</div>
            <div class="metric-value">${metric.domSize?.numericValue ?? '–'}</div>
            <div class="metric-sub">dom-size</div>
          </div>
          <div class="col-md-4">
            <div class="metric-label">Total Bytes</div>
            <div class="metric-value">
              ${metric.totalBytes?.displayValue || (metric.totalBytes?.numericValue
            ? (metric.totalBytes.numericValue / 1024).toFixed(0) + ' KB'
            : '–')}
            </div>
            <div class="metric-sub">total-byte-weight</div>
          </div>
          <div class="col-md-4">
            <div class="metric-label">JS Exec Time</div>
            <div class="metric-value">${metric.jsExecution?.displayValue || '–'}</div>
            <div class="metric-sub">bootup-time</div>
          </div>
        </div>
        <div class="mt-2">
          <div class="d-flex justify-content-between align-items-center mb-1">
            <span class="small text-muted">Diagnostics</span>
            <span class="badge bg-light text-secondary badge-pill">
              ${issuesCount} issues
            </span>
          </div>
          <ul class="list-unstyled mb-0 small">
            ${diagItemsHtml || '<li class="text-muted">No key issues</li>'}
          </ul>
        </div>
      </div>

      <div class="card-footer bg-white border-0 pt-0">
        <span class="small text-muted">
          Device: ${page.formFactor || 'unknown'} · Throttling: ${page.throttling}
        </span>
      </div>
    </div>`;
}

export function getHtmlPerformanceMetrics() {
    const pages = wcagResult.lighthousePerformanceMetrics;
    const cardsHtml = pages.map(buildCard).join('\n');
    const now = new Date().toISOString();

    return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Lighthouse Performance & SEO Dashboard</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <style>
    body { background-color:#f5f5f7; }
    .wrapper-80 { max-width:80vw; margin:0 auto; }
    .score-badge {
      font-weight:600;
      border-radius:999px;
      padding:0.15rem 0.55rem;
      font-size:0.8rem;
    }
    .score-good { background:#0c9b4b; color:#fff; }
    .score-ok   { background:#f7a928; color:#000; }
    .score-bad  { background:#d93025; color:#fff; }
    .metric-label { font-size:0.8rem; text-transform:uppercase; color:#666; }
    .metric-value { font-weight:600; }
    .metric-sub { font-size:0.75rem; color:#777; }
    .url-text { font-size:0.9rem; word-break:break-all; }
  </style>
</head>
<body>
  <div class="container-fluid py-4">
    <div class="wrapper-80">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3 mb-0">Lighthouse Performance & SEO</h1>
        <span class="text-muted small">Generated: ${now}</span>
      </div>

      ${cardsHtml}

    </div>
  </div>
</body>
</html>`;
} 