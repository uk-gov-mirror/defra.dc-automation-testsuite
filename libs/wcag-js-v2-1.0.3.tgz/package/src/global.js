export let wcagResult = {
    visitedPageUrls: new Map(),
    startDateTime: '',
    isErrorFound: false,
    axeViolations: [],
    axeStatistics: [],
    lighthouseViolations: [],
    lighthouseStatistics: [],
    lighthousePerformanceMetrics:[]
};